package com.servicenow.utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class Baselib 
{
	public static WebDriver driver ; 
	@BeforeMethod
	@Parameters("browser")
	public void setup(String browser) {
		if(browser.equalsIgnoreCase("internet"))
		{
		    System.setProperty ("webdriver.ie.driver","./exefiles/IEDriverServer.exe");
		    driver = new InternetExplorerDriver();
		    
		    //for remote script run
		    
		    //driver = new RemoteWebDriver(DesiredCapabilities.internetExplorer());
		    
		    driver.get("https://nttdata.onelogin.com/login");
		    driver.manage().window().maximize();
		    driver.manage().deleteAllCookies();
		}
		else if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty ("webdriver.chrome.driver","./exefiles/chromedriver.exe");
			driver = new ChromeDriver();

			//for remote script run
		    
		    //driver = new RemoteWebDriver(DesiredCapabilities.chrome());
		    
            driver.get("https://nttdata.onelogin.com/login");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();	
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty ("webdriver.chrome.driver","./exefiles/chromedriver.exe");
			driver = new ChromeDriver();

			//for remote script run
		    
		    //driver = new RemoteWebDriver(DesiredCapabilities.firefox());
		    
            driver.get("https://nttdata.onelogin.com/login");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();	
		}
	}
	
	
	@AfterMethod
	public void teardown(ITestResult result) 
	{
		//driver.quit();
		
	}

}
