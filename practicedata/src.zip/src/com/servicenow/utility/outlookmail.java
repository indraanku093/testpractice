package com.servicenow.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class outlookmail {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./exefiles/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().deleteAllCookies();
		driver.get("https://outlook.office.com");
        driver.findElement(By.id("i0116")).sendKeys("180138@nttdata.com");
        
        driver.findElement(By.id("idSIButton9")).click();
        Thread.sleep(10000);
        driver.findElement(By.id("passwordInput")).sendKeys("Ankuindra093@");
        driver.findElement(By.id("submitButton")).click();
        Thread.sleep(20000);
        driver.findElement(By.xpath("//div[contains(text(),'New message')]")).click();
       
        Thread.sleep(10000);
        
        
        
        
        //sender in to 
        WebElement to = driver.findElement(By.xpath("//input[@class='ms-BasePicker-input pickerInput_269bfa71']"));
        to.sendKeys("sonal.khampariya@nttdata.com");
        Thread.sleep(1000);
        to.sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        
        //sender in cc
        WebElement cc = driver.findElements(By.xpath("//input[@class='ms-BasePicker-input pickerInput_269bfa71']")).get(1);
        cc.sendKeys("indrajeet11.kumar@nttdata.com");
        Thread.sleep(1000);
        cc.sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        
        //subject data
        driver.findElement(By.id("subjectLine0")).sendKeys("automation report");
        Thread.sleep(2000);
        
        //message body
        WebElement msg = driver.findElement(By.xpath("//div[@aria-label='Message body' and @role='textbox']"));
        msg.sendKeys("This message is automated message:\n *******test report attached file*********");
        Thread.sleep(1000);
        
        //add attachement
        driver.findElements(By.name("Attach")).get(0).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'Browse this computer')]")).click();
        Runtime.getRuntime().exec("./exefiles/uploadfile.exe");
        Thread.sleep(20000);
        
        //send button
        driver.findElements(By.xpath("//div[contains(text(),'Send')]")).get(1).click();
        Thread.sleep(1000);
        
        //logout
        driver.findElement(By.xpath("//img[@alt=\"KI\"]")).click();
        driver.findElement(By.id("meControlSignoutLink")).click();
        Thread.sleep(1000);
        driver.quit();

	}

}
