package com.servicenow.testscripts.change;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.Pattern;
import org.testng.ISuiteListener;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.servicenow.pagerepo.onelogin;
import com.servicenow.pagerepo.change.itilhomepage;
import com.servicenow.utility.Baselib;
import com.servicenow.utility.Excelsheet;
import com.servicenow.utility.screenshotlib;
import com.servicenow.utility.waitlib;

public class testscripts extends Baselib 
{
	@Test(priority=1, enabled=false)
	public void login() throws Exception, Exception
	{
		onelogin ol =new onelogin(driver);
		
		ol.usernameclick(1, 0);
		waitlib.isleep(1000);
		
		ol.passwordclick(1, 1);
		waitlib.isleep(1000);
		
		ol.submit();
		waitlib.isleep(40000);
		
//		String msg = driver.findElement(By.xpath("//div[@class='error-message']")).getText();
//		System.out.println(msg);
		ol.usertextdisplay();
		
		//attach the following test case
		Excelsheet.datareadcond("./Testdata/Change Test Cases.xlsx", "Change Module", "TC002", 2, 35);
		
	}
	
	
	@Test(priority=2, enabled=false)
	public void createchange() throws IOException, Exception 
	{
		
		onelogin ol=new onelogin(driver);
		
		ol.usernameclick(1, 0);
		waitlib.isleep(1000);
		
		ol.passwordclick(1, 1);
		waitlib.isleep(1000);
		
		ol.submit();
		waitlib.isleep(30000);
		
		
		
		
	   ol.UATclick();
	   waitlib.isleep(30000);
	
	   itilhomepage itil = new itilhomepage(driver);
	   waitlib.isleep(10000);
	
	   itil.filter();
	   waitlib.isleep(5000);
	
	   itil.createnew();
	   waitlib.isleep(5000);
	
	   itil.frame();
	
	   itil.ch();	
	
	   waitlib.isleep(5000);
	   itil.changeid();
	   
	   itil.enviroment();
	
	   itil.shortdec();
	
	
	   itil.cmdb();
	
	
	   itil.assignementgroup();
	
	   //itil.submitform();
	  
	 
	 //attach the following test case
	 Excelsheet.datareadcond("./Testdata/Change Test Cases.xlsx", "Change Module", "TC002", 2, 35);
	 		
	}
	
	@Test(priority=3)
	public void searchchange() throws IOException, Exception
	{
       onelogin ol=new onelogin(driver);
		
		ol.usernameclick(1, 0);
		waitlib.isleep(1000);
		
		ol.passwordclick(1, 1);
		waitlib.isleep(1000);
		
		ol.submit();
		waitlib.isleep(30000);
		
		
		
		
	   ol.UATclick();
	   waitlib.isleep(30000);
	
	   itilhomepage itil = new itilhomepage(driver);
	   waitlib.isleep(20000);
	
	   itil.clicksearch();
//	   
//	   itil.clickrequestbutton();
//	   waitlib.isleep(3000);
//	   
//	   itil.categoryselection("Add");
//	   waitlib.isleep(4000);
//	   
	   waitlib.isleep(5000);
	   itil.tabsdatafilling("Schedule");
	   waitlib.isleep(5000);
	   
	   itil.clickalllocation();
	   
	   
	   itil.impersonateuser("Kavya H K");
	   waitlib.isleep(5000);
	   
	   itil.impersonateuser("Sonal Khampariya");
	   //itil.changemanagementgroup();
	   waitlib.isleep(5000);
	   
	   //itil.assignedto();
	   waitlib.isleep(5000);
	   
	   itil.time();
	   
	 //attach the following test case
	 Excelsheet.datareadcond("Change Test Cases", "Change Module", "TC002", 2, 35);
	   
	}
	
	

}
