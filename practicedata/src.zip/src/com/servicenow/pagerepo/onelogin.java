package com.servicenow.pagerepo;

import java.io.IOException;
import java.util.Iterator;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.servicenow.utility.Baselib;
import com.servicenow.utility.Excelsheet;
import com.servicenow.utility.screenshotlib;

public class onelogin extends Baselib 
{
    
	WebDriver driver;
	
    @FindBy(id="user_email")
	WebElement username;
	
	@FindBy(id="user_password")
	WebElement password;
	
	@FindBy(id="user_submit")
	WebElement submit;
	
	@FindBy(xpath ="//div[contains(text(), 'SK')]")
	WebElement usertextdisplay;
	
	@FindBy(xpath=("//div[contains(text(),'UAT')]"))
	WebElement UAT;
	
	@FindBy(xpath="//div[@class='error-message']")
	WebElement errormsg;
	
	public onelogin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public void usernameclick(int i, int j) throws IOException, Exception
	{
		username.sendKeys(Excelsheet.datareadencrypted(i,j));
	}
	
	public void passwordclick(int i , int j) throws IOException, Exception
	{
		password.sendKeys(Excelsheet.datareadencrypted(i, j));
	}
	
	public void submit() {
		submit.click();
	}
	
	public void UATclick() {
		UAT.click();
		Set<String> et = driver.getWindowHandles();
		Iterator<String> st =et.iterator();
		st.next();
		String childId = st.next();
		
		driver.switchTo().window(childId);
	}
	
	public void usertextdisplay() throws IOException {
		
		String actual = usertextdisplay.getText();
		System.out.println(actual);
		
			
		
			try {
				Assert.assertEquals(actual, "SK");
				System.out.println("login Pass");
				screenshotlib.screenshot(driver, "login");
			} catch (Exception e) {
				
				String msg = errormsg.getText();
				System.out.println(msg);
			}
		
			
		
		
			
		
		
		
	}
	
		
		
	
	
	
}
