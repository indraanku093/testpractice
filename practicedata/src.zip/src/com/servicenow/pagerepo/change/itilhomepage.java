package com.servicenow.pagerepo.change;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.FindFailed;


import com.servicenow.utility.Baselib;
import com.servicenow.utility.Excelsheet;
import com.servicenow.utility.waitlib;

public class itilhomepage extends Baselib {
	static int  i=0;
	@FindBy(id = "filter")
	WebElement filter ;
	
	@FindBy(xpath= "//a[@id='323bb07bc611227a018aea9eb8f3b35e']")
	WebElement createnew ; 
	
	@FindBy(id = "gsft_main")
	WebElement frame;
	
	@FindBy(id = "change_request.u_change_reason")
	WebElement changereason ; 
   
	@FindBy(id = "change_request.u_change_environment")
    WebElement chgenvironment ;
   
    @FindBy(id = "lookup.change_request.cmdb_ci")
    WebElement cmdb ;
   
    @FindBy(id = "change_request.short_description")
    WebElement shortdec ; 

    @FindBy(id="lookup.change_request.assignment_group")
    WebElement searchbutton;
   
    @FindBy(id="group_tree")
    List<WebElement> grouptree;
    
    @FindBy(id="sysverb_insert")
    WebElement submitButton;
    
    @FindBy(id="sys_readonly.change_request.number")
    WebElement changeid;
   
    @FindBy(xpath="//span[@class='input-group-addon-transparent icon-search sysparm-search-icon']")
    WebElement globalsearch;
    
    @FindBy(id="sysparm_search")
    WebElement globalsearchdata;
    
    @FindBy(xpath="//button[contains(text(), 'Request Approval')]")
    WebElement requestapprovalbutton;
    
    @FindBy(xpath="//span[@class='outputmsg_text']")
    WebElement errormsgrequest;
    
    @FindBy(id="change_request.category")
    WebElement category;
    
    @FindBy(xpath="//span[@class='tab_caption_text']")
    List<WebElement> tabs;
    
    @FindBy(id="label.ni.change_request.u_all_locations")
    WebElement alllocation;
    
    @FindBy(id="lookup.change_request.u_change_management_group")
    WebElement changemangroupserach;
    
    @FindBy(id="lookup.change_request.assigned_to")
    WebElement searchassignedto;
    
    @FindBy(id="user_info_dropdown")
    WebElement impersonatedropdown;
    
    @FindBy(id="nav-settings-button")
    WebElement settingbutton;
    
    public itilhomepage(WebDriver driver) 
   {
	Baselib.driver=driver;
	PageFactory.initElements(driver, this);
   }
  
   public void filter() {
	filter.sendKeys("change");
	filter.sendKeys(Keys.ENTER);
   }

   public void createnew() {
	createnew.click();
   }

   public void frame() {
	driver.switchTo().frame(frame);
   }
	
   public void ch() {
		Select ch1 = new Select(changereason);
	ch1.selectByValue("New Functionality");
		
	}
	
   public void enviroment() {
		Select en = new Select (chgenvironment);
		en.selectByValue("Development");
	}
	
   public void cmdb() throws InterruptedException, FindFailed {
	cmdb.click();
	Set<String> et1 = driver.getWindowHandles();
	Iterator<String> st12 =et1.iterator();
	st12.next();
	st12.next();
	String child = st12.next();
	
	driver.switchTo().window(child);
	waitlib.isleep(10000);
	WebElement el = driver.findElements(By.xpath("//input[@id = 'cmdb_ci_table_header_search_control' ]")).get(0);
	 
	 el.sendKeys("10.90.105.50");
	 el.sendKeys(Keys.ENTER);
	 waitlib.isleep(5000);
	 driver.findElement(By.className("glide_ref_item_link")).click();

	 Set<String> et = driver.getWindowHandles();
		Iterator<String> st =et.iterator();
		st.next();
		String childId = st.next();
		driver.switchTo().window(childId);
		waitlib.isleep(5000);
		
}

   public void shortdec() {
	shortdec.sendKeys("Test");
    }

   public void assignementgroup() throws InterruptedException, FindFailed
   {

	
	
	driver.switchTo().frame(frame);

	driver.findElement(By.id("lookup.change_request.assignment_group")).click();
	

	waitlib.isleep(10000);
	Set<String> data1 = driver.getWindowHandles();
	Iterator<String> st =data1.iterator();
	st.next();
	st.next();
	String cd = st.next();
	driver.switchTo().window(cd);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//a[@name='26ea10fc0fea4600272e244be1050e0f']")));
	driver.findElement(By.xpath("//a[@name='26ea10fc0fea4600272e244be1050e0f']")).click();
//	for (int i = 0; i < grouptree.size(); i++) 
//	{
//		String st1 = grouptree.get(i).getText();
//		if(st1.equalsIgnoreCase("Dell New Test User"))
//		{
//			
//			driver.findElement(By.xpath("//a[@name='79ed76744f30cb00a9e3e3414210c743']")).click();
//			break;
//		}
//		System.out.println(st1);
//	}
	Set<String> et = driver.getWindowHandles();
	Iterator<String> t =et.iterator();
	t.next();
	String childId = t.next();
	driver.switchTo().window(childId);
	waitlib.isleep(5000);
   }

   public void submitform()
   {
	
	driver.switchTo().frame(frame);
	submitButton.click();
	driver.switchTo().alert().accept();
	
	
    }
   
   public void changeid() throws EncryptedDocumentException, IOException {
	  String et5 = changeid.getAttribute("value");
	  System.out.println(et5);
	  i=Excelsheet.datawrite(5, 0, et5);
   }
   
   public void clicksearch() throws IOException, Exception
   {
	   waitlib.isleep(4000);
	   globalsearch.click();
	   waitlib.isleep(3000);
	   globalsearchdata.sendKeys(Excelsheet.datareadencrypted(i, 0), Keys.ENTER);
	   
   }

   public void clickrequestbutton()
   {
     

	   driver.switchTo().frame(frame);
	   waitlib.ewait(driver, requestapprovalbutton, 40);
	   requestapprovalbutton.click();
       System.out.println(errormsgrequest.getText());
     
   }
   
   
   public void categoryselection(String categorydata)
   {
	   Select sc=new Select(category);
	   sc.selectByValue(categorydata);
   }
   
   
   public void tabsdatafilling(String tabname) throws InterruptedException
   {
	waitlib.isleep(5000);
	driver.switchTo().frame(frame);
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	jse.executeScript("window.scrollBy(0,300)", "");
	   for(int i=0; i<=4; i++)
	   {
	   //System.out.println(tabs.get(i).getText());
	   if(tabs.get(i).getText().equalsIgnoreCase(tabname))
	   {
		   tabs.get(i).click();
		   
	   }
	   
	   }
   }
   
   public void clickalllocation()
   {
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   //js.executeScript("scroll(0, 400);");
	   js.executeScript("arguments[0].scrollIntoView();", alllocation);
	   alllocation.click();
   }
   
   public void changemanagementgroup()
   {
	   changemangroupserach.click();
	   Set<String> w = driver.getWindowHandles();
	   Iterator<String> it = w.iterator();
	   it.next();
	   it.next();
	   String child = it.next();
	   driver.switchTo().window(child);
	   
	   
	   
	   
	   Set<String> w1 = driver.getWindowHandles();
	   Iterator<String> it1 = w1.iterator();
	   it1.next();
	   String child1 = it1.next();
	   driver.switchTo().window(child1);
   }
   
   public void assignedto()
   {
	   searchassignedto.click();
	   Set<String> w = driver.getWindowHandles();
	   Iterator<String> it = w.iterator();
	   it.next();
	   it.next();
	   String child = it.next();
	   driver.switchTo().window(child);
	   driver.findElement(By.id("sys_user_table_header_search_control")).sendKeys("sonal khampariya", Keys.ENTER);
	   driver.findElement(By.className("glide_ref_item_link")).click();
	   
	   Set<String> w1 = driver.getWindowHandles();
	   Iterator<String> it1 = w1.iterator();
	   it1.next();
	   String child1 = it1.next();
	   driver.switchTo().window(child1);
   }
   
   public void impersonateuser(String name) throws InterruptedException
   {
	   driver.switchTo().defaultContent();
	   impersonatedropdown.click();
	   driver.findElement(By.xpath("//a[contains(text(), 'Impersonate User')]")).click();
	   driver.findElement(By.id("select2-chosen-2")).click();
	   driver.findElement(By.id("s2id_autogen2_search")).click();
	   driver.findElement(By.id("s2id_autogen2_search")).sendKeys(name);
	   waitlib.isleep(3000);
	   driver.findElement(By.id("s2id_autogen2_search")).sendKeys(Keys.ENTER);
   }
   
   public void settingtimezone()
   {
	
	   driver.switchTo().defaultContent();
	   settingbutton.click();
	   WebElement timezone = driver.findElement(By.id("timezone_picker_select"));
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   //js.executeScript("scroll(0, 400);");
	   js.executeScript("arguments[0].scrollIntoView();", timezone);
	   
	   Select sc = new Select(timezone);
	   sc.selectByVisibleText("IST");
	   driver.findElement(By.xpath("//button[@class='btn close icon-cross']")).click();
   }
   
   public void time() throws InterruptedException
   {
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   js.executeScript("scroll(0, 400);");
	   
	   waitlib.isleep(4000);
	   Date date = Calendar.getInstance().getTime();  
	     DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
	     String strDate = dateFormat.format(date);  
	     System.out.println("Converted String: " + strDate);
	     String[] data = strDate.split(" ");
	     System.out.println("date : "+ data[0]);
	     System.out.println("time : "+ data[1]);
	     String[] data1 = data[1].split(":");
	     String hh = data1[0];
	     String mm = data1[1];
	     String ss = data1[2];
	     System.out.println("Hours : " + hh);
	     System.out.println("Minutes : " + mm);
	     System.out.println("Seconds : " + ss);
	     
	     int d = Integer.parseInt(mm);
	     d=d+4;
	     String mt = Integer.toString(d);
	     String kt = new String();
	     kt = data[0]+" "+hh+":"+d+":"+ss;
	     System.out.println(kt);
	     driver.findElement(By.id("change_request.start_date")).sendKeys(kt);
   }
}